import React, { useState } from 'react';
import { StyleSheet, View, Text, TextInput, TouchableOpacity, FlatList } from 'react-native';

const App = () => {
  const [expense, setExpense] = useState('');
  const [amount, setAmount] = useState('');
  const [expenses, setExpenses] = useState([]);

  const addExpense = () => {
    if (expense && amount) {
      setExpenses((prevExpenses) => [
        ...prevExpenses,
        { id: Math.random().toString(), expense, amount: parseFloat(amount) },
      ]);
      setExpense('');
      setAmount('');
    }
  };

  const deleteExpense = (id) => {
    setExpenses((prevExpenses) => prevExpenses.filter((item) => item.id !== id));
  };

  const calculateGrossExpense = () => {
    return expenses.reduce((total, item) => total + item.amount, 0);
  };

  const renderExpenseItem = ({ item }) => (
    <TouchableOpacity style={styles.expenseItem} onPress={() => deleteExpense(item.id)}>
      <Text style={styles.expenseText}>{item.expense}: ₹{item.amount.toFixed(2)}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Expense Tracker</Text>
      <TextInput
        style={styles.input}
        placeholder="Expense"
        value={expense}
        onChangeText={setExpense}
        placeholderTextColor="#ccc" // Optional: Change placeholder text color
      />
      <TextInput
        style={styles.input}
        placeholder="Amount"
        value={amount}
        keyboardType="numeric"
        onChangeText={setAmount}
        placeholderTextColor="#ccc" // Optional: Change placeholder text color
      />
      
      <TouchableOpacity style={styles.button} onPress={addExpense}>
        <Text style={styles.buttonText}>Add Expense</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={styles.button} onPress={() => alert(`Gross Expense: ₹${calculateGrossExpense().toFixed(2)}`)}>
        <Text style={styles.buttonText}>Calculate Gross Expense</Text>
      </TouchableOpacity>

      <FlatList
        data={expenses}
        renderItem={renderExpenseItem}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: 'purple',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
    color: '#fff', // Set input text color to white
    backgroundColor: '#333', // Optional: Set background color for better contrast
  },
  button: {
    backgroundColor: 'black',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  expenseItem: {
    padding: 15,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  expenseText: {
    fontSize: 18,
  },
});

export default App;
